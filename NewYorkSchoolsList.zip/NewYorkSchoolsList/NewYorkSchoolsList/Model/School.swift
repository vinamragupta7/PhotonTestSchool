//
//  School.swift
//  NewYorkSchoolsList
//
//  Created by Gupta Vinamra (RPP0ZXP) on 2/21/24.
//

import Foundation

struct School {
    let schoolName: String
    let boro : String
    let overviewDesc: String
}
