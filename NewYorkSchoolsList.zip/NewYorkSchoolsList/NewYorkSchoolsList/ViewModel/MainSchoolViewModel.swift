//
//  MainSchoolViewModel.swift
//  NewYorkSchoolsList
//
//  Created by Gupta Vinamra (RPP0ZXP) on 2/21/24.
//

import Foundation

class MainSchoolViewModel {
    
    var schoolName: String = ""
    var boro: String = ""
    
}
